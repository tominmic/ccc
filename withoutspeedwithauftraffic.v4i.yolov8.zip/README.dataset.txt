# traffic > 2025-06-17 6:32pm
https://universe.roboflow.com/tomin/traffic-nqcuv

Provided by a Roboflow user
License: CC BY 4.0

